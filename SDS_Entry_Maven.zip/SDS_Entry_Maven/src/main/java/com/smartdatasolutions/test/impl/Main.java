package com.smartdatasolutions.test.impl;

import com.smartdatasolutions.test.Member;
import com.smartdatasolutions.test.MemberExporter;
import com.smartdatasolutions.test.MemberFileConverter;
import com.smartdatasolutions.test.MemberImporter;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Main extends MemberFileConverter {

	@Override
	protected MemberExporter getMemberExporter() {
	    return new MemberExporterImpl();
	}

	@Override
	protected MemberImporter getMemberImporter() {
	    return new MemberImporterImpl();
	}


	@Override
	protected List<Member> getNonDuplicateMembers(List<Member> membersFromFile) {
	    Set<Member> memberSet = new HashSet<>(membersFromFile);
	    return new ArrayList<>(memberSet);
	}



	@Override
	protected Map<String, List<Member>> splitMembersByState(List<Member> validMembers) {
	    Map<String, List<Member>> membersByState = new HashMap<>();
	    
	    for (Member member : validMembers) {
	        String state = member.getState();
	        membersByState.computeIfAbsent(state, k -> new ArrayList<>()).add(member);
	    }
	    
	    return membersByState;
	}



	public static void main(String[] args) {
	    try {
	        File inputFile = new File("/Users/rajeshpradhan/Downloads/SDS_Entry_Maven/Members.txt");
	        String outputPath = "/Users/rajeshpradhan/Downloads/SDS_Entry_Maven"; // Ensure this directory exists
	        String outputFileName = "outputFile.csv";
	        
	        // Initialize and run the conversion
	        MemberFileConverter converter = new Main();
	        converter.convert(inputFile, outputPath, outputFileName);
	        
	        System.out.println("Conversion completed successfully.");
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}




}
