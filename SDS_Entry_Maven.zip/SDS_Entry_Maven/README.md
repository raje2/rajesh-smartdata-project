Smart Data Solutions : Aptitude Test
------------------------------------


What you are expected to do:
---------------------------
First, save your personal information on ApplicantInfo.txt file 
and go through Test1.txt and Test2.txt for the information about your tasks.

	
Timeframe :
---------
You are given 1.5 hr to complete the tasks.


